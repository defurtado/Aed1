/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_33474_29787;

/** @author: Hendy S.Fortes nº33474 Engenheria Informática && 
 *           Denise H.T.Furtado nº29787 Informática e Gestão
 */
public class MaratonaDoPorto {
    
    MaratonaDoPorto(){  }//Constructor MaratonaDoPorto
    
    private boolean registarAtleta(Atleta atl,Corrida corr){
        return true;
    }
    
    public boolean registarAtletaFunRace(int num,String nom){
        return true;
    }
    
    public boolean registarAtletaFamilyRace(int num,String nom){
        return true;
    }
        
    public boolean registarAtletaMaratona(int num,String nom){
        return true;
    }
    
    public void iniciarCorridas(){
        
    }
    
    public boolean registarChegadaAtleta(int num){
        return false;
    }
    
    public double calcVelocMediaAtleta(int num){
        return 1.0;
    }
    
    //public String temposToString(){return String;}
    
    //public String vencedoresToString(){return String;}
    
}
