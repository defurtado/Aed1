/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_33474_29787;

import java.util.Date;

/**
 *
 * @author Hendy
 */
public class Corrida {
    private final double distancia;
    private Date partida;

    Corrida(double d){
        this.distancia = d;
    }//constructor (corrida)

    public void iniciarCorrida(){
        
    }
    
    public boolean addAtleta(Atleta a){
        return true;
    }
    
    public double getDistancia(){
        return 1.0;
    }
    
    //public Date getHoraPartida(){ }
    
    //public String temposToString(){}
    
    // public Atleta findVencedor(){return new Atleta;}
    
    //public String vencedorToString(){;}
   
    //public String nomeCorrida(){ ;}
        
}

