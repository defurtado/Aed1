/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_33474_29787;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author Hendy
 */
public class Atleta implements Comparable{
    private int numero;
    private String nome;   
    private Date chegada;
    
    Atleta(int num,String nom, Corrida c) {
        this.nome = nom;
        this.numero = num;
    }

    public int getNumero() {
        return numero;
    }
    
    public void registarChegada(){
        
    }
    
    public double calcTempoEmSegundos(){
        return 1.0;
    }  

    public double calVelocMedia(){
        return 1.0;
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Atleta other = (Atleta) obj;
        if (this.numero != other.numero) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.chegada, other.chegada)) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "Atleta{" + "numero=" + numero + ", nome=" + nome + ", chegada=" + chegada + '}';
    }
    
    @Override
    public int compareTo(Atleta outro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
